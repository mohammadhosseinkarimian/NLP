import data_cleaner
import collect_alphabets
import collect_hrefs
import collect_articles

if __name__ == "__main__":
    collect_alphabets.func()
    collect_hrefs.func()
    collect_articles.func()
    data_cleaner.func()
