# RelationExtractionInPersian
This git repository created for the final project of the **"Natural Language Processing course, IUST, Dr. Minaei-Bidgoli, Semester 002"**

In this project, we want to implement a model as RESTAPI service to extract the relations from the Persian sentences dataset using two global dependences tools `Seraji` & `PerDT`. We use a part of Persian Wikipedia sentences as our dataset.

Project contributors: 

* Danial Bazmandeh, BSc, Computer Engineering
* M. Hossein Karimian, BSc, Computer Engineering
