from transformers import AutoConfig, AutoTokenizer, AutoModel
from sklearn import datasets
from sklearn.model_selection import train_test_split

wine = datasets.load_wine('../data/cleaned/cleaned_dataset.json')
X = wine.data
print(X.shape)

y = wine.target
print(y.shape)

dX_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
#80 percent training
#20 percent test

for